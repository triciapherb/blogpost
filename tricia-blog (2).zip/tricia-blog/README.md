# Tricia Blog

A Pen created on CodePen.io. Original URL: [https://codepen.io/triciapherb/pen/2fef6d5aef46b902734aa66c5e7ff824](https://codepen.io/triciapherb/pen/2fef6d5aef46b902734aa66c5e7ff824).

My blog about my interest in real estate.